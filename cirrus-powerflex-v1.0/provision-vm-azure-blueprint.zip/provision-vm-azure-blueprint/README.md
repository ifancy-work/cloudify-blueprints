# Terraform example blueprints

These blueprints highlight how to use Terraform, via Cloudify, to create resources in **Azure**. The blueprint itself simply references an external Terraform module to further demonstrate that re-development is not needed to use Cloudify to orchestrate your virtual environments. 