# Overview

The blueprints in this directory demonstrate the use of Terraform to provision an application (NGINX) running on a deployed server in the cloud platform of your choice. Terraform deploys the necessary resources (VPCs, networking, instances, etc.), and Ansible configures the instances once they have been created.

# Blueprints

The following example blueprint is provided:

* [azure.yaml](./azure.yaml)

The blueprints are very similar, with the exception of the Terraform used to deploy to the appropriate cloud provider and any corresponding credentials used by Terraform.

## Prerequisites

All blueprints require a `private_key_content` secret with a private key that Ansible will use to connect to the deployed hosts. This should be the private key for the corresponding public key that is specified via the `public_key_content` deployment input. For example, to upload a private key using the CLI:

```
cfy secrets create -uf .ssh/id_rsa private_key_content
```

### Azure

The Azure blueprint example requires the following secrets to be configured in your Cloudify manager:

* `azure_client_id` - The client ID (or `appId`) from the Service Principal JSON.
* `azure_client_secret` - The client password (or `password`) from the Service Principal JSON.
* `azure_subscription_id` - The ID of the Azure subscription to use.
* `azure_tenant_id` - The ID of the Azure tenant to use.

Please see the [official Azure documentation](https://docs.microsoft.com/en-us/azure/developer/java/sdk/identity-service-principal-auth) for information about creating a Service Principal and assigning it the appropriate roles.
